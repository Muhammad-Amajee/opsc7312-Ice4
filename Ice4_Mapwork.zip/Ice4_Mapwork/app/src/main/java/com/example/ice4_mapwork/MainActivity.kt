package com.example.ice4_mapwork

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // For example, call registerUser or loginUser here based on your UI actions
        registerUser("user@example.com", "password123")
    }

    private fun registerUser(email: String, password: String) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Registration success
                    Log.d("FirebaseAuth", "User registered successfully")
                } else {
                    // Registration failed
                    Log.w("FirebaseAuth", "Registration failed", task.exception)
                }
            }
    }

    private fun loginUser(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Login success
                    Log.d("FirebaseAuth", "User logged in successfully")
                } else {
                    // Login failed
                    Log.w("FirebaseAuth", "Login failed", task.exception)
                }
            }
    }
}

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the MapView
        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)

        // Asynchronously load the map
        mapView.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Set a default location (e.g., a landmark) and move the camera
        val defaultLocation = LatLng(37.7749, -122.4194) // Example: San Francisco
        googleMap.addMarker(MarkerOptions().position(defaultLocation).title("Default Location"))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12f))

    }

    // Handle the MapView lifecycle
    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }
}

private lateinit var fusedLocationClient: FusedLocationProviderClient

override fun onMapReady(map: GoogleMap) {
    googleMap = map

    // Check if location permission is granted
    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        == PackageManager.PERMISSION_GRANTED) {
        googleMap.isMyLocationEnabled = true

        // Get user's current location
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val userLatLng = LatLng(location.latitude, location.longitude)
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))
            }
        }
    } else {
        // Request permission
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }
}

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize MapView
        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)

        // Initialize FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Check if location permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED) {
            googleMap.isMyLocationEnabled = true

            // Get user's last known location
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val userLatLng = LatLng(location.latitude, location.longitude)
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))

                    // Optional: Add a marker at the user's location
                    googleMap.addMarker(MarkerOptions().position(userLatLng).title("You are here"))
                }
            }
        } else {
            // Request permission if not already granted
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    // Handle the MapView lifecycle methods
    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    // Handle the result of the permission request
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // If permission is granted, reinitialize the map to enable location features
            googleMap.isMyLocationEnabled = true

            // Get the last known location again (if needed)
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val userLatLng = LatLng(location.latitude, location.longitude)
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 15f))
                }
            }
        }
    }
}

import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private lateinit var googleMap: GoogleMap
    private var selectedLandmark: LatLng? = null

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Enable user location (assuming permissions are granted)
        googleMap.isMyLocationEnabled = true

        // Add some landmarks for the user to select from
        val landmark1 = LatLng(37.7749, -122.4194) // Example landmark (San Francisco)
        val landmark2 = LatLng(40.7128, -74.0060) // Example landmark (New York)
        googleMap.addMarker(MarkerOptions().position(landmark1).title("San Francisco"))
        googleMap.addMarker(MarkerOptions().position(landmark2).title("New York"))

        // Set a click listener on the map's markers
        googleMap.setOnMarkerClickListener(this)
    }

    override fun onMarkerClick(marker: com.google.android.gms.maps.model.Marker): Boolean {
        // Get the position of the selected landmark
        selectedLandmark = marker.position

        // Display a toast message or UI feedback
        Toast.makeText(this, "Landmark selected: ${marker.title}", Toast.LENGTH_SHORT).show()

        // You can now proceed to calculate the route to this landmark
        getDirectionsToLandmark()

        // Return true to indicate that the click event has been handled
        return true
    }

    private fun getDirectionsToLandmark() {
        // Logic for calculating the route to the selected landmark (Step 6)
        if (selectedLandmark != null) {
            // Call Directions API or custom algorithm here
        }
    }
}

private fun getDirectionsToLandmark() {
    val origin = "${userLocation.latitude},${userLocation.longitude}"  // User's current location
    val destination = "${selectedLandmark?.latitude},${selectedLandmark?.longitude}"  // Selected landmark location

    // Directions API URL
    val directionsUrl = "https://maps.googleapis.com/maps/api/directions/json?" +
            "origin=$origin&destination=$destination&key=YOUR_GOOGLE_MAPS_API_KEY"

    // Make a network request to fetch directions
    getDirectionsFromAPI(directionsUrl)
}

private fun getDirectionsFromAPI(url: String) {
    val client = OkHttpClient()

    val request = Request.Builder()
        .url(url)
        .build()

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Failed to get directions", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onResponse(call: Call, response: Response) {
            response.body?.string()?.let { responseData ->
                // Parse the response data to extract the route information
                parseDirectionsResponse(responseData)
            }
        }
    })
}

private fun parseDirectionsResponse(jsonData: String) {
    val gson = Gson()
    val directionsResponse = gson.fromJson(jsonData, DirectionsResponse::class.java)

    // Extract route information (polylines, duration, distance)
    val route = directionsResponse.routes[0]
    val overviewPolyline = route.overview_polyline.points  // Encoded polyline string
    val distance = route.legs[0].distance.text  // Total distance
    val duration = route.legs[0].duration.text  // Estimated time

    // Display route on the map
    runOnUiThread {
        drawRouteOnMap(overviewPolyline)
        Toast.makeText(this@MainActivity, "Distance: $distance, Duration: $duration", Toast.LENGTH_LONG).show()
    }
}

private fun drawRouteOnMap(overviewPolyline: String) {
    // Decode the polyline
    val decodedPath = PolyUtil.decode(overviewPolyline)

    // Add the polyline to the map
    googleMap.addPolyline(PolylineOptions().addAll(decodedPath).color(Color.BLUE).width(5f))
}

val distance = route.legs[0].distance.text  // e.g., "5 km"
val duration = route.legs[0].duration.text  // e.g., "15 mins"

Toast.makeText(this, "Distance: $distance, Duration: $duration", Toast.LENGTH_LONG).show()

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private var selectedLandmark: LatLng? = null
    private lateinit var userLocation: LatLng

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        // Assuming location permissions are granted, enable user location
        googleMap.isMyLocationEnabled = true

        // Set marker click listener to select a landmark
        googleMap.setOnMarkerClickListener { marker ->
            selectedLandmark = marker.position
            getDirectionsToLandmark()
            true
        }

        // Get user location using FusedLocationProviderClient (as in Step 4)
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                userLocation = LatLng(location.latitude, location.longitude)
            }
        }
    }

    private fun getDirectionsToLandmark() {
        val origin = "${userLocation.latitude},${userLocation.longitude}"
        val destination = "${selectedLandmark?.latitude},${selectedLandmark?.longitude}"

        val directionsUrl = "https://maps.googleapis.com/maps/api/directions/json?" +
                "origin=$origin&destination=$destination&key=YOUR_GOOGLE_MAPS_API_KEY"

        getDirectionsFromAPI(directionsUrl)
    }

    private fun getDirectionsFromAPI(url: String) {
        // OkHttp request to Directions API
        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Failed to get directions", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.body?.string()?.let { responseData ->
                    parseDirectionsResponse(responseData)
                }
            }
        })
    }

    private fun parseDirectionsResponse(jsonData: String) {
        // Parse the response and extract route, distance, and duration (as described above)
        val gson = Gson()
        val directionsResponse = gson.fromJson(jsonData, DirectionsResponse::class.java)

        val route = directionsResponse.routes[0]
        val overviewPolyline = route.overview_polyline.points
        val distance = route.legs[0].distance.text
        val duration = route.legs[0].duration.text

        runOnUiThread {
            drawRouteOnMap(overviewPolyline)
            Toast.makeText(this@MainActivity, "Distance: $distance, Duration: $duration", Toast.LENGTH_LONG).show()
        }
    }

    private fun drawRouteOnMap(overviewPolyline: String) {
        val decodedPath = PolyUtil.decode(overviewPolyline)
        googleMap.addPolyline(PolylineOptions().addAll(decodedPath).color(Color.BLUE).width(5f))
    }
}

private fun parseDirectionsResponse(jsonData: String) {
    val gson = Gson()
    val directionsResponse = gson.fromJson(jsonData, DirectionsResponse::class.java)

    // Extract route information (polylines, duration, distance)
    val route = directionsResponse.routes[0]
    val overviewPolyline = route.overview_polyline.points  // Encoded polyline string
    val distance = route.legs[0].distance.text  // Total distance
    val duration = route.legs[0].duration.text  // Estimated time

    // Display route on the map
    runOnUiThread {
        drawRouteOnMap(overviewPolyline)

        // Step 7: Display estimated time and distance
        val distanceTextView: TextView = findViewById(R.id.distanceTextView)
        val timeTextView: TextView = findViewById(R.id.timeTextView)

        distanceTextView.text = "Distance: $distance"
        timeTextView.text = "Estimated Time: $duration"

        // Notify the user via toast as well (optional)
        Toast.makeText(this@MainActivity, "Distance: $distance, Duration: $duration", Toast.LENGTH_LONG).show()
    }
}

if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
!= PackageManager.PERMISSION_GRANTED) {
    ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
}

findViewById<Button>(R.id.registerButton).setOnClickListener {
    val email = findViewById<EditText>(R.id.emailInput).text.toString()
    val password = findViewById<EditText>(R.id.passwordInput).text.toString()
    registerUser(email, password)
}

findViewById<Button>(R.id.loginButton).setOnClickListener {
    val email = findViewById<EditText>(R.id.emailInput).text.toString()
    val password = findViewById<EditText>(R.id.passwordInput).text.toString()
    loginUser(email, password)
}
